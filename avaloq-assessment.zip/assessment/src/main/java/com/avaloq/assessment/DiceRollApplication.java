package com.avaloq.assessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiceRollApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiceRollApplication.class, args);
	}

}
